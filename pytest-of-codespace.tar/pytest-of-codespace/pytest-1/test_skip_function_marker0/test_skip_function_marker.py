import pytest
@pytest.mark.skip(reason="0.37899674648861525")
def test_skip():
    assert True