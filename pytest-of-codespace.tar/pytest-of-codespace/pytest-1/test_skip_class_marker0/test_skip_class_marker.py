import pytest
@pytest.mark.skip(reason="0.05048055530823525")
class TestSkip:
    def test_skip():
        assert True