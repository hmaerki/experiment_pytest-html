import pytest
@pytest.mark.xfail(reason="0.9679939041029628")
def test_xfail():
    assert False