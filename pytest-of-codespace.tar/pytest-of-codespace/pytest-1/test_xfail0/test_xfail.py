import pytest
def test_xfail():
    pytest.xfail("0.4722984254591077")