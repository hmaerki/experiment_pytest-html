import pytest
def test_skip():
    pytest.skip("0.416890138554606")