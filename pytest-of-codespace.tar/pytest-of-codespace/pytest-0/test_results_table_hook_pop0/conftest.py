def pytest_html_results_table_header(cells):
    cells.pop()

def pytest_html_results_table_row(report, cells):
    cells.pop()