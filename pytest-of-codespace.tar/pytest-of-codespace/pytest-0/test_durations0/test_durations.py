import time
def test_sleep():
    time.sleep(0.4)