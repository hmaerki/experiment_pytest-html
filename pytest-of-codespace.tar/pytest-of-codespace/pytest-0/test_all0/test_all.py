import pytest
@pytest.fixture
def setup():
    error

def test_error(setup):
    assert True

def test_pass():
    assert True

def test_fail():
    assert False