import pytest
@pytest.mark.xfail(reason="0.2386015129188518")
def test_xfail():
    assert False