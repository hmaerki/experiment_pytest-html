import pytest
def test_xfail():
    pytest.xfail("0.8866857107582858")