import pytest
import time

@pytest.mark.flaky(reruns=2)
def test_example():
    time.sleep(0.2)
    assert False