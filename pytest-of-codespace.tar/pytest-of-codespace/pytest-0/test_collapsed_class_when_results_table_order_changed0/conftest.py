def pytest_html_results_table_header(cells):
    cells.append(cells.pop(0))

def pytest_html_results_table_row(report, cells):
    cells.append(cells.pop(0))