import pytest

@pytest.hookimpl(hookwrapper=True)
def pytest_runtest_makereport(item, call):
    outcome = yield
    report = outcome.get_result()
    if report.when == 'call':
        from pytest_html import extras
        report.extras = [extras.json({'0.6498026346106798': '0.9508050698910836'})]