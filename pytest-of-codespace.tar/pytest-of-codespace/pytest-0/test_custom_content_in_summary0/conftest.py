import pytest

def pytest_html_results_summary(prefix, summary, postfix):
    prefix.append(r"<p>prefix is 0.06345874239346305</p>")
    summary.extend([r"<p>summary is 0.9437097050690497</p>"])
    postfix.extend([r"<p>postfix is 0.531310103619964</p>"])