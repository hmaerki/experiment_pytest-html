import pytest
@pytest.mark.xfail()
class TestXPass:
    def test_xpass(self):
        assert True