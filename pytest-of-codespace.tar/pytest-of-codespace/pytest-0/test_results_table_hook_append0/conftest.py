def pytest_html_results_table_header(cells):
    cells.append("<th>Description</th>")
    cells.append(
        '<th class="sortable time" data-column-type="time">Time</th>'
    )

def pytest_html_results_table_row(report, cells):
    cells.append("<td>A description</td>")
    cells.append('<td class="col-time">A time</td>')