def pytest_html_duration_format(duration):
    return str(round(duration * 1000)) + " seconds"