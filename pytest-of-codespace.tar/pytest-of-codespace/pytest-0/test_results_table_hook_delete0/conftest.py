def pytest_html_results_table_row(report, cells):
    if report.skipped:
        del cells[:]