import pytest
def test_skip():
    pytest.skip('reason')

def test_pass(): pass