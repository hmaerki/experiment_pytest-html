import pytest

@pytest.hookimpl(hookwrapper=True)
def pytest_runtest_makereport(item, call):
    outcome = yield
    report = outcome.get_result()
    from pytest_html import extras
    report.extras = [extras.url(f'{report.when}')]