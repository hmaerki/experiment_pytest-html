import pytest
@pytest.mark.xfail()
def test_xpass():
    assert True