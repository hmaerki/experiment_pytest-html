import pytest
@pytest.mark.skip(reason="0.6620592910036692")
class TestSkip:
    def test_skip():
        assert True