import pytest

@pytest.hookimpl(hookwrapper=True)
def pytest_runtest_makereport(item, call):
    outcome = yield
    report = outcome.get_result()
    if report.when == 'call':
        from pytest_html import extras
        report.extras = [extras.html('<div>0.8951838474341554</div>')]