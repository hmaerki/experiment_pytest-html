def pytest_html_results_table_header(cells):
    cells.append(
        '<th class="sortable alpha" data-column-type="alpha">Alpha</th>'
    )

def pytest_html_results_table_row(report, cells):
    data = report.nodeid.split("_")[-1]
    cells.append(f'<td class="col-alpha">{data}</td>')