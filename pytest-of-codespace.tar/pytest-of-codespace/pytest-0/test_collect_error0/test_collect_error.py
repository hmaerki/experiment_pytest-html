import pytest
raise ImportError("Non existent module")