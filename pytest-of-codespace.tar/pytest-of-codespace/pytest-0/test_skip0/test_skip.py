import pytest
def test_skip():
    pytest.skip("0.17548466273263752")