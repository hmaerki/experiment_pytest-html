import pytest
import logging
@pytest.fixture
def setup():
    logging.info("this is setup")
    error
    yield
    logging.info("this is teardown")



def test_logging(setup):
    logging.info("this is test")
    assert True