import pytest

def pytest_html_results_summary(prefix, summary, postfix, session):
    print(prefix)
    print(summary)
    print(postfix)
    print(session)