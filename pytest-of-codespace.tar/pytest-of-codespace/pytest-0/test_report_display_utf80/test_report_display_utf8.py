import pytest
@pytest.mark.parametrize("utf8", [("测试用例名称")])
def test_pass(utf8):
    assert True