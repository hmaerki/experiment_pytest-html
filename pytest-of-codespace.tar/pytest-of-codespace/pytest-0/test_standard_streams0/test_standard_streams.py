import pytest
import sys
@pytest.fixture
def setup():
    print("this is setup stdout")
    print("this is setup stderr", file=sys.stderr)
    yield
    print("this is teardown stdout")
    print("this is teardown stderr", file=sys.stderr)

def test_streams(setup):
    print("this is call stdout")
    print("this is call stderr", file=sys.stderr)
    assert True