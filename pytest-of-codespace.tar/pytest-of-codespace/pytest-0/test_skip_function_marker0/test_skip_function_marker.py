import pytest
@pytest.mark.skip(reason="0.46250696758805854")
def test_skip():
    assert True