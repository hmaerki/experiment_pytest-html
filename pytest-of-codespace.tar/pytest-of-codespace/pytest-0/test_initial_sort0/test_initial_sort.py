import pytest
from time import sleep

def test_AAA():
    sleep(0.3)
    assert True

def test_BBB():
    sleep(0.2)
    assert False

def test_CCC():
    sleep(0.1)
    assert True