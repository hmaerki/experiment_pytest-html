import pytest
@pytest.fixture
def arg(request):
    raise ValueError()
def test_function(arg):
    pass