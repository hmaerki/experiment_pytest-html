import pytest
import logging
@pytest.fixture
def setup():
    logging.info("this is setup")

    yield
    logging.info("this is teardown")
    error


def test_logging(setup):
    logging.info("this is test")
    assert False