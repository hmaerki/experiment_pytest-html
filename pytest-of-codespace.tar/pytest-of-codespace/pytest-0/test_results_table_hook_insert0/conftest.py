def pytest_html_results_table_header(cells):
    cells.insert(2, "<th>Description</th>")
    cells.insert(
        1,
        '<th class="sortable time" data-column-type="time">Time</th>'
    )

def pytest_html_results_table_row(report, cells):
    cells.insert(2, "<td>A description</td>")
    cells.insert(1, '<td class="col-time">A time</td>')