import pytest

@pytest.fixture
def changing_dir(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)

def test_function(changing_dir):
    pass