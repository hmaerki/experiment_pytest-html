import pytest
@pytest.mark.xfail(reason="broken")
class TestXFail:
    def test_xfail(self):
        assert False